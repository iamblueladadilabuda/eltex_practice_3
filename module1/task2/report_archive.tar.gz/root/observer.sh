conf_file="observer.conf"
log_file="observer.log"

if [[ ! -f $conf_file ]];
then
echo "Файл конфигурации $conf_file не найден."
exit 
fi

while IFS= read -r script || [[ -n "$script" ]];
do
[[ -z "$script" || "$script" =~ ^# ]] && continue

script_name=$(basename "$script")

if ! pgrep -f "$script_name" > /dev/null;
then
nohup bash "$script" > /dev/null 2>&1 &
pid=$!

datetime=$(date '+%m-%d %H:%M')
echo "[$datetime] Перезапущен скрипт: $script_name с PID $pid" >> "$log_file"
fi
done < "$conf_file"
