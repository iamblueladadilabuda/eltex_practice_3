filename=$(basename "$0")

if [ filename=="template_task.sh" ];
then
echo "Я бригадир, сам не работаю"
exit
fi

report_file="report_${filename}.log"

pid=$$
start=$(date '+%m-%d %H:%M')
echo "[$pid] $start Скрипт запущен" >> "$report_file"

wait_time=$(( RANDOM % 1771 + 30 ))
sleep wait_time

minutes=$(( wait_time / 60 ))
end=$(date '+%m-%d %H:%M')
echo "[$pid] $end Скрипт завершился, работал $minutes минут" >> "$report_file"

